class BaseDevice:
    def __init__(self) -> None:
        super().__init__()

    @staticmethod
    def discover() -> list:
        result = []
        return result

    @staticmethod
    def get() -> list:
        result = []
        return result
